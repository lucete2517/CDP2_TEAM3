﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace directshow
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            axWindowsMediaPlayer1.uiMode = "none";
            axWindowsMediaPlayer1.stretchToFit = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (axWindowsMediaPlayer1.playState == WMPPlayState.wmppsPaused)
            {
                axWindowsMediaPlayer1.Ctlcontrols.play();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(axWindowsMediaPlayer1.playState == WMPPlayState.wmppsPlaying)
            {
                axWindowsMediaPlayer1.Ctlcontrols.pause();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.Drawing.Image ret = null;
            try
            {
                Bitmap bitmap = new Bitmap(axWindowsMediaPlayer1.Width, axWindowsMediaPlayer1.Height);//캡처크기
                {
                    Graphics g = Graphics.FromImage(bitmap);
                    {
                        Graphics gg = axWindowsMediaPlayer1.CreateGraphics();
                        {
                            this.BringToFront();

                            g.CopyFromScreen(
                             axWindowsMediaPlayer1.PointToScreen(
                                 new System.Drawing.Point()).X + 100,
                             axWindowsMediaPlayer1.PointToScreen(
                                 new System.Drawing.Point()).Y + 100,
                             0, 0,
                             new System.Drawing.Size(
                                 axWindowsMediaPlayer1.Width,
                                 axWindowsMediaPlayer1.Height)
                             );
                        }
                    }
                    using (MemoryStream ms = new MemoryStream())
                    {
                        bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                        ret = System.Drawing.Image.FromStream(ms);
                        string save_name = DateTime.Now.ToString("yyyy-MM-dd-hh시mm분ss초");//시간을이름으로
                        ret.Save("C:\\Users\\USER\\source\\repos\\directshow\\directshow\\" + save_name + ".jpg");//저장위치
                        pictureBox1.Image = ret;
                    }
                }
                bitmap.Dispose();

            } catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }


        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    axWindowsMediaPlayer1.URL = ofd.FileName;
                    axWindowsMediaPlayer1.Visible = true;
                }
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }
        
        private void button5_Click(object sender, EventArgs e)
        {
            string a = axWindowsMediaPlayer1.PointToScreen(new System.Drawing.Point()).X.ToString();
            string b = axWindowsMediaPlayer1.PointToScreen(new System.Drawing.Point()).Y.ToString();
            string c = button1.PointToScreen(new System.Drawing.Point()).X.ToString();
            string d = button1.PointToScreen(new System.Drawing.Point()).Y.ToString();
            MessageBox.Show(a + " " + b + " " + c + " " + d);
        }

        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {

        }
    }
}