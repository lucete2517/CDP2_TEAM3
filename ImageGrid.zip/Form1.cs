﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace ImageGrid
{
    public partial class Form1 : Form
    {
        private GridManager m_gm1 = null;
        private GridManager m_gm2 = null;
        private GridManager m_gm3 = null;

        public Form1()
        {
            InitializeComponent();

            m_gm1 = new GridManager(dgv1);
            m_gm2 = new GridManager(dgv2);
            m_gm3 = new GridManager(dgv3);

            LoadSampleImages();

        }

        private void LoadSampleImages()
        {
            int i = 0;

            string[] files = Directory.GetFiles(@"C:\test", "*.jpg");

            m_gm1.Add(files[0]);
            m_gm1.Add(files[1]);

            files = Directory.GetFiles(@"C:\test", "*.jpg");

            for(i = 0; i < files.Length; i++)
            {
                m_gm2.Add(files[i]);
            }

            lb2.Text = "B 부위 (" + m_gm2.GetImagesCount().ToString() + ")";

            files = Directory.GetFiles(@"C:\test", "*.jpg");

            for (i = 0; i < files.Length; i++)
            {
                m_gm3.Add(files[i]);
            }

            lb3.Text = "C 부위 (" + m_gm3.GetImagesCount().ToString() + ")";
        }
    }
}
