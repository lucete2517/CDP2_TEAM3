﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageGrid
{
    public class CapObject
    {
        public int idx;
        public double precision;//정확도
        public string imgPath;//이미지 원본 저장경로
    }
}
