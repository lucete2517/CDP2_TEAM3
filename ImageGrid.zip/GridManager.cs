﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ImageGrid
{
    class GridManager 
    {
        private DataGridView m_dgv;
        private List<CapObject> m_capObj;

        private int m_selectedCellIndex;

        public GridManager( DataGridView dgv)
        {
            m_dgv = dgv;
            this.m_capObj = new List<CapObject>();

            SetDefaultGridFeature();

            m_dgv.CellPainting += OnCellPainting;
            m_dgv.CellClick += OnCellClick;
            m_dgv.DoubleClick += OnDoubleClick;
        }

        private void SetDefaultGridFeature()
        {
            m_dgv.ColumnHeadersVisible = false;
            m_dgv.RowHeadersVisible = false;
            m_dgv.RowCount = 1;
            m_dgv.ColumnCount = 0;

            Padding newPadding = new Padding(5, 5, 5, 5);
            m_dgv.RowTemplate.DefaultCellStyle.Padding = newPadding;

            DataGridViewRow row = this.m_dgv.RowTemplate;
            row.DefaultCellStyle.BackColor = Color.Black;
            row.Height = 100;//160X100
        }

        public void Add(string imgPath)
        {
            DataGridViewImageColumn imgCol = new DataGridViewImageColumn();
            imgCol.ImageLayout = DataGridViewImageCellLayout.Zoom;
            m_dgv.Columns.Add(imgCol);

            int idx = m_dgv.ColumnCount - 1;

            m_dgv.Columns[idx].Width = 160;

            Image image = new Bitmap(imgPath);
            Image pThumbnail = image.GetThumbnailImage(160, 100, null, new IntPtr());
            m_dgv.Rows[0].Cells[idx].Value = pThumbnail;

            var obj = new CapObject();
            obj.idx = idx;
            obj.precision = 96.5;
            obj.imgPath = imgPath;

            m_capObj.Add(obj);
        }

        private void OnCellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            e.PaintBackground(e.CellBounds, true);
            e.PaintContent(e.CellBounds);
            e.Handled = true;

            var rectDest = new RectangleF(e.CellBounds.X + 10, e.CellBounds.Y + 10, e.CellBounds.Width, e.CellBounds.Height);
            e.Graphics.DrawString(m_capObj[e.ColumnIndex].precision.ToString() + "%", new Font("Arial", 12, FontStyle.Regular), Brushes.Yellow, rectDest, null);
        }

        private void OnCellClick(object sender, DataGridViewCellEventArgs e)
        {
            m_selectedCellIndex = m_dgv.CurrentCell.ColumnIndex;
        }

        private void OnDoubleClick(object sender, EventArgs e)
        {
            Image img = Image.FromFile(m_capObj[m_selectedCellIndex].imgPath);

            var frm = new Form();

            frm.Width = img.Width;
            frm.Height = img.Height;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Text = "Image Viewer";

            PictureBox pb = new PictureBox();
            pb.Parent = frm;
            pb.Dock = DockStyle.Fill;
            pb.Image = img;

            frm.ShowDialog();
        }

        public int GetImagesCount()
        {
            return m_capObj.Count;
        }

    }
}
