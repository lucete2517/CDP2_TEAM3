﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenCvSharp;

namespace testv
{
    public partial class Form1 : Form
    {

        VideoCapture cap = new VideoCapture("Test.mp4");
        Mat frame = new Mat();

        bool IsPlaying = false;

        public Form1()
        {
            InitializeComponent();

            trackBar1.Minimum = 0;
            trackBar1.Maximum = Convert.ToInt32(cap.Get(CaptureProperty.FrameCount));

            label1.Text = "Total Flames " + trackBar1.Maximum.ToString();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            frame.Release();
            cap.Release();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            cap.Read(frame);

            if(cap.Get(CaptureProperty.PosFrames) == cap.Get(CaptureProperty.FrameCount))
                cap.Set(CaptureProperty.PosFrames, 0);
            

            if(!frame.Empty())
                pictureBox1.Image = OpenCvSharp.Extensions.BitmapConverter.ToBitmap(frame);

            int curPos = Convert.ToInt32(cap.Get(CaptureProperty.PosFrames));

            trackBar1.Value = curPos;

            label2.Text = "Current Flames " + curPos.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = !timer1.Enabled;
            IsPlaying = !IsPlaying;

            if (IsPlaying)
                button1.Text = "Pause";
            else
                button1.Text = "Play";
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            cap.Set(CaptureProperty.PosFrames, trackBar1.Value);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox2.Image = pictureBox1.Image;
        }
    }
}
